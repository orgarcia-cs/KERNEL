void memory_copy(char *source, char *dest, int nbytes);
void int_to_ascii(int n, char str[]);
